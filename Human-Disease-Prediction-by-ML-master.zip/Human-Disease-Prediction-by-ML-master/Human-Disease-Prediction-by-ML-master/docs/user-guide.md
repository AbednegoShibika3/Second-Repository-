# User Guide

## Getting Started

### Accessing the Application
1. Open your web browser
2. Navigate to `http://localhost:5000` (if running locally)
3. You'll see the main interface with the symptom selection panel

## Using the Interface

### Selecting Symptoms
1. **Search Method**:
   - Use the search box to find specific symptoms
   - Type part of the symptom name to filter the list
   - Click on symptoms to select/deselect them

2. **Manual Input**:
   - Type symptoms directly in the input field
   - Separate multiple symptoms with commas
   - Press Enter or click "Predict" to submit

### Making Predictions
1. Select at least three symptoms
2. Click the "Predict" button
3. Wait for the system to process (loading animation will show)
4. View the prediction result
5. Read the medical disclaimer

### Dark/Light Mode
- Click the moon/sun icon in the top-right corner
- The interface will switch between dark and light themes
- Your preference is saved for future visits

## Understanding Results

### Prediction Display
- The system shows your selected symptoms
- Displays the predicted condition
- Includes a medical disclaimer
- Allows for new predictions

### Error Messages
- **Invalid Symptoms**: Shows which symptoms are not recognized
- **Minimum Symptoms**: Reminds you to select at least three symptoms
- **Duplicate Symptoms**: Warns about repeated symptoms
- **System Errors**: Provides clear error messages if something goes wrong

## Best Practices

### For Accurate Predictions
1. Select specific symptoms rather than general ones
2. Choose at least three symptoms
3. Avoid selecting contradictory symptoms
4. Use the search function to find exact symptom names

### Important Notes
- This is an AI-based prediction system
- Not a substitute for professional medical advice
- Use for preliminary screening only
- Always consult healthcare professionals for proper diagnosis

## Troubleshooting

### Common Issues
1. **Symptoms Not Found**
   - Use the search function
   - Check spelling
   - Try alternative terms

2. **System Not Responding**
   - Check your internet connection
   - Refresh the page
   - Clear browser cache

3. **Interface Issues**
   - Try a different browser
   - Check browser compatibility
   - Update your browser

## Support
For additional help or to report issues:
1. Check the documentation
2. Submit an issue on GitHub
3. Contact the development team 