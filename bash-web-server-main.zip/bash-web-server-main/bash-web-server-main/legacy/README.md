# Legacy Scripts

This folder contains experimental and development versions of the server that were used during development:

- `server-tiny-pure.sh` - Minimal test server
- `server-ultra-pure.sh` - Ultra-minimal server implementation  
- `client-pure.sh` - Test client script
- `demo-pure.sh` - Demo script

These are kept for reference but are not part of the main package.
